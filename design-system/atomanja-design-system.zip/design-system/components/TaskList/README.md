The Gantt as rows: deadline on the left, task in the middle, the one action on the right.

- **You provide:** the same `tasks`, `role` and handlers as every task view: `onMarkSent` (worker), `onMarkReceived`, `onClaim` and `canClaim` (witness), optional `me` to limit "Mark received" to the claiming witness.
- This is the default on a phone. Each row is at least `row` tall and the action drops under the task below 520px.
- A debt row adds the amount, who claimed it and both marks. Events sit under their task.
- A late deadline is printed in `late`.
- Sort by deadline, late first; the component keeps the order it is given.
