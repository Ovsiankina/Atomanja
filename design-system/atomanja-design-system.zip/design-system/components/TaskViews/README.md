One set of tasks, four layouts: a Gantt that turns into a list, a table or a Kanban board with the switch above it.

- **You provide:** `tasks`, `today`, `role` and the handlers (`onMarkSent`, `onMarkReceived`, `onClaim`, `canClaim`, `me`). Optional `title`, `defaultView` (default `gantt`), or `view` plus `onViewChange` to control it, and `views` to offer fewer.
- This is the body of both dashboards. Put `Totals` above it.
- Switching view never changes or refetches data; all four read the same array, so a mark set in one shows in the others.
- Default to `gantt` on desktop and `list` on a phone. Remember the person's last choice.
- Worker dashboard: `role="worker"`, `onMarkSent`. Witness dashboard: `role="witness"`, `onMarkReceived`, and `canClaim` with `onClaim` only when there are two or more witnesses.
