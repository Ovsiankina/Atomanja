One line saying Vikunja changed something and the locked deadline did not.

- **You provide:** `type` (`moved`, `removed`, `deleted`), `at` (ISO date), and for `moved` the `from` and `to` dates. Children replace the default sentence.
- Place it directly under the task it belongs to; the task views do this from `task.events`.
- Glyphs: `↦` moved, `∅` removed, `×` deleted. Text is `ink-muted`, the glyph `ink`.
- The sentence always ends by saying the deadline still counts.
