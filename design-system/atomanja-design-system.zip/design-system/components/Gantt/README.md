Tasks on a day grid: a bar from start to deadline, a lock tick on the deadline, and a hatched overrun while the debt is unpaid.

- **You provide:** `tasks` (see the task object in Product recap), `today` (ISO date), `role`. Optional `from` and `to`; otherwise the range fits the tasks plus a margin. Optional `amount` and `currency`.
- Reading a row: the bar is the planned span; the 2px `ink` tick is the locked deadline; a `late` hatch runs from the deadline to today; a hollow diamond marks where Vikunja moved the date (the tick does not move); the note after the bar gives the status and amount.
- Bar colour is the status: `surface` outline for upcoming, `late`, `accent` for sent, `confirmed` for received. The `accent` vertical is today.
- A task without `start` draws a one-day bar on its deadline.
- `role="witness"` shows `Task 47` in the label column instead of the title.
- The label column is sticky; days are at least `day` wide and the grid scrolls sideways inside its frame on a phone.
- It is read-only: no dragging, no resizing. Atomanja never writes to Vikunja.
- To show the same data as a list, table or board, use `TaskViews`.
