The two marks of one debt, side by side: Sent by the worker, Received by the witness.

- **You provide:** `sent` and `received` (ISO date, `true`, or falsy), `role` (`worker` or `witness`), and the handler for that role: `onSent` or `onReceived`.
- Both roles always see both marks. Only the role's own unset mark becomes a button.
- A set mark shows a filled `ink` box and its date in `data`. An unset one says "Not yet".
- Use it where one debt is the subject (a detail screen, a notification landing). Rows and cards use the compact check pair built into the task views.
- Marks are never undone from the interface.
