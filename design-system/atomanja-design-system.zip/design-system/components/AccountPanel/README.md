Who is in this Atomanja: the one worker, the witnesses, the admin witness, and the invite link.

- **You provide:** `worker` (name), `witnesses` (`{name, role: "witness" | "admin", state: "active" | "invited"}`), optional `me` to tag the reader's own row, `onInvite`, `inviteLink` once created, `onSignOut`.
- Worker settings pass `onInvite`. Witness settings leave it out and the invite block disappears.
- The link is shown read-only and selected on focus. Atomanja does not send it; say so.
- The admin witness row always reads "Sees fake data only".
- There is exactly one worker. Do not offer to add or remove one.
