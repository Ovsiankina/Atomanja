Atomanja turns missed Vikunja deadlines into 10 CHF debts owed to a witness. It only counts. The interface reads like a ledger on a dark technical drawing: hairlines, big light type, small mono labels, square corners, and colour only where money is involved.

## Voice

- State facts. "Late = 10 CHF, once per task." No encouragement, no blame, no exclamation marks, no emoji.
- Sentence case for copy and buttons ("Mark sent", "Invite a witness"). Uppercase only happens in the `label` style, and the style does it.
- Buttons are verb first and name the mark they set: "Mark sent", "Mark received", "Claim", "Agree", "Decline".
- Amounts are number then currency: `10 CHF`. Dates are day then short month: `14 Nov`. Both in `data`.
- Address the reader as "you". Name the others by role: worker, witness, admin witness.
- Say what Atomanja does not do when it matters: "Send it yourself.", "It still counts.", "Fake data."
- A witness never sees a task title. Write `Task 47`, never the title, on any witness or admin surface.

## Colour

- Dark is the primary theme; light is the same system inverted. Never hard-code a value, both themes share every component.
- Ground is `bg`. Text is `ink`, secondary text `ink-muted`. Most of a screen is only these three plus `line`.
- Colour means status and nothing else:
  - `late`: a deadline was missed and money is owed.
  - `accent`: the worker marked the money sent. Also the today line and focus rings.
  - `confirmed`: the witness marked it received.
  - Upcoming has no colour: `ink-muted` with a hollow mark.
- Every status carries its word (see `Tag`); colour never stands alone.
- Solid buttons are `ink` on `bg`, not a colour. Text on an `accent` fill is `on-fill`.
- No gradients, no shadows, no tinted panels. The one texture is the `late` hatch on a Gantt overrun.

## Type

- Hanken Grotesk for everything read as language, Geist Mono for everything read as data. Load both from Google Fonts; the stacks are `--font-sans` and `--font-mono`.
- Display sizes (`display-xl`, `display-lg`, `display-md`) are light (300 to 400) with tight tracking. Use one per screen: a total, the wordmark, one statement.
- `body` for task titles and controls, `body-sm` for hints and events.
- `label` (mono, uppercase, tracked) names things: column heads, tags, sections. `index` numbers them: `/0.1`, `/0.2` for sections, `#47` for tasks. `data` carries dates and amounts with tabular numerals.
- Never bold for emphasis. Size and position do that job.

## Layout

- Build on a column grid with hairlines, not boxes. A section opens with a `line-strong` rule; rows inside it are split by `line`.
- Phone first: `space-4` page margin, one column, totals stay three across. From 900px use `space-12` margins and a 12 column grid; put the label and index in the left columns and the content to the right.
- Rows are at least `row` tall. Controls are `control`, row actions `control-sm`.
- Number sections with `/0.1`, `/0.2` in `index` next to their `label`.
- Leave air: `space-8` between sections, `space-20` above a display statement on desktop.
- Wide data (Gantt, table, Kanban) scrolls sideways inside its own frame; the page never does.

## Shape, borders, states

- Corners are `radius-none`. `radius-pill` is reserved for a progress track.
- Every edge is one `hairline`. Controls use `line-strong`, dividers use `line`. Cards are `surface` with a `line` border; there is no elevation.
- Hover inverts: an outline button fills with `ink`. A solid button fills with `accent`.
- Focus is a 2px solid `accent` outline, 2px off the control.
- Disabled keeps its place with a `line` border and `ink-muted` text.
- Dashed borders mean "not real": fake data banners and tags.

## Motion

- None by default. State changes are instant. If a transition is needed, 120ms linear on colour only.

## Iconography

- No icon set. Glyphs come from the fonts: `→` on forward actions, `✓` in a set mark, `↦` deadline moved, `∅` deadline removed, `×` task deleted.
- Status marks are 6px squares: hollow for upcoming, filled for the rest.
- There is no logo. Set the name "Atomanja" in `display-lg`.

## Using the components

- Wrap the app in an element with class `at-root`; it sets ground, ink and the sans stack.
- Components are React 18, global `Atomanja`. All four task views take the same `tasks` array and the same handlers, so switching view never changes data. Use `TaskViews` unless a screen needs one fixed view.
- Pass `role="witness"` on witness and admin surfaces. It swaps titles for task numbers and worker actions for witness actions.
- The components never write to Vikunja and never move money. Handlers only set marks.
- The map from each app view to components is in the Product recap section.
