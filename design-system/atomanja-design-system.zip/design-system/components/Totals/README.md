Owed, Sent, Confirmed as three big numerals under a rule.

- **You provide:** `owed`, `sent`, `confirmed` as numbers, optional `currency` (default CHF).
- It opens both dashboards, above the task views. It stays three across on a phone.
- Owed turns `late` when above zero. The other two stay `ink`: money that moved is not an alarm.
- Each column carries its `/0.n` index and a `label`. Do not add a fourth total.
