The sign-in form, and the same form for a witness accepting an invite.

- **You provide:** `mode` (`login` default, `invite`), `onSubmit(values)`, optional `error`, and for invites the `inviter` name.
- `login` sets "Atomanja" in display type and asks for name and password.
- `invite` states who is asking and what a witness will see, then asks for a new password twice. The witness sets their own password; the worker never does.
- One solid full-width button. Errors appear above it in `late`.
- Centre it on `bg` with nothing else on the screen.
