# Product recap

Atomanja is a small web app, installable on the phone home screen, that turns missed Vikunja deadlines into 10 CHF debts owed to a witness.

## Rules

- **Reads Vikunja only.** Every task with a deadline counts. Atomanja never writes to Vikunja.
- **Deadlines are locked in.** Atomanja records a deadline the first time it sees it. Moving the date, removing it or deleting the task does not cancel it; the change shows up as an event.
- **Late = 10 CHF, once per task.** No other penalties. Changing the amount needs every witness to agree.
- **Claiming.** With one witness, a late debt is claimed for them automatically. With two or more, the first witness to claim it gets it.
- **Two marks per debt.** The worker marks "sent", the witness marks "received". Both see both marks.
- **Accounts.** One worker. Witnesses join by invite and set their own password. One admin witness that only sees fake data.
- **Push notifications.** Witness: a task went late; the worker marked money sent. Worker: a debt was claimed; a witness marked money received.
- **No money handling.** Atomanja only counts. Payment happens outside it.

## Task states

| State | Meaning | Colour | Kanban column |
|---|---|---|---|
| `upcoming` | Deadline not reached | none (`ink-muted`) | Upcoming |
| `late` | Deadline passed, 10 CHF owed | `late` | Late |
| `sent` | Worker marked the money sent | `accent` | Sent |
| `received` | Witness marked it received | `confirmed` | Confirmed |

Totals: **Owed** sums `late`, **Sent** sums `sent`, **Confirmed** sums `received`.

## Views and what builds them

| # | View | Components | Notes |
|---|---|---|---|
| 1 | Login | `AuthCard` | `mode="login"` |
| 2 | Accept invite (witness) | `AuthCard` | `mode="invite"`, pass `inviter` |
| 3 | Worker dashboard | `Totals`, `TaskViews` | `role="worker"`, `onMarkSent`. Titles shown. Events sit under their task. |
| 4 | Witness dashboard | `Totals`, `TaskViews` | `role="witness"`, `onMarkReceived`; `canClaim` and `onClaim` only with 2+ witnesses. Task numbers only. |
| 5 | Worker settings | `AccountPanel`, `AmountProposal` | `onInvite` creates the link; `role="worker"` proposes and sees votes. |
| 6 | Witness settings | `AmountProposal`, `AccountPanel` | `role="witness"` with `onAgree` and `onDecline`. No `onInvite`. |
| 7 | Notifications setup | `InstallSteps` | Steps for iPhone, then "Enable notifications". |
| 8 | Admin view | `Banner`, then view 4 | `Banner tone="fake"` pinned above the witness dashboard, fed fake data. |

## The task object

Every task view takes the same array.

| Field | Type | Meaning |
|---|---|---|
| `n` | number | Task number. The only identity a witness sees. |
| `title` | string | Worker only. Never send it to a witness client. |
| `start` | ISO date, optional | Start of the Gantt bar. Without it the bar is one day. |
| `deadline` | ISO date | The locked deadline, as first seen. |
| `movedTo` | ISO date, optional | Where Vikunja moved it. Drawn as a hollow diamond; the lock stays. |
| `status` | `upcoming`, `late`, `sent`, `received` | See Task states. |
| `amount` | number, optional | Defaults to 10. |
| `claimedBy` | string or null | Witness name. |
| `sent`, `received` | ISO date or boolean | The two marks. |
| `events` | array | `{type: "moved", from, to, at}`, `{type: "removed", at}`, `{type: "deleted", at}` |
