The one way to act: a square button with a hairline border that inverts on hover.

- **You provide:** the label as children, `onClick`, and optionally `variant` (`outline` default, `solid`, `ghost`), `size="sm"`, `block`, `arrow`.
- Use `solid` for the one action that sets a mark or submits a form ("Mark sent", "Sign in"). One solid button per row or form.
- Use `outline` for everything else, `ghost` for leaving ("Sign out").
- `arrow` pushes a mono arrow to the right edge; use it on actions that go somewhere or create something. Pass a string to change the glyph.
- `size="sm"` (`control-sm`) inside rows, cards and table cells.
- Labels are sentence case, verb first, no punctuation.
- Do not colour a button by status. `late` and `confirmed` are never button fills.
