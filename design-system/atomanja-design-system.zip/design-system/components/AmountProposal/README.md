The amount per late task, and the vote that is needed to change it.

- **You provide:** `current`, `role`, and when a proposal is open `proposed` and `votes` (`{name, vote: "agreed" | "declined" | "pending"}`). Handlers: `onPropose(amount)` for the worker, `onAgree` and `onDecline` for a witness.
- Without `proposed` it shows the current amount; the worker also gets the field to propose a new one.
- With `proposed` it shows current → proposed, the count of agreements and one row per witness. A witness gets Agree and Decline.
- The amount changes only when every witness agreed. Never show the proposed amount as if it were in force.
