A four-way segmented control: Gantt, List, Table, Kanban.

- **You provide:** `value`, `onChange(view)`, and optionally `views` to offer fewer.
- The selected segment is filled `ink`. Order is fixed.
- `TaskViews` already contains it. Use it alone only when the switch sits away from the view, for example in a page header.
