import * as React from 'react';

export type Role = 'worker' | 'witness';
export type TaskStatus = 'upcoming' | 'late' | 'sent' | 'received';
export type TaskEvent =
  | { type: 'moved'; from: string; to: string; at?: string }
  | { type: 'removed' | 'deleted'; at?: string };
export interface Task {
  /** Task number. The only identity a witness sees. */
  n: number;
  id?: string | number;
  /** Worker only. */
  title?: string;
  /** ISO date. Start of the Gantt bar. */
  start?: string;
  /** ISO date. The locked deadline, as first seen. */
  deadline: string;
  /** ISO date. Where Vikunja moved it; the lock stays on deadline. */
  movedTo?: string;
  status: TaskStatus;
  /** Defaults to 10. */
  amount?: number;
  claimedBy?: string | null;
  sent?: string | boolean;
  received?: string | boolean;
  events?: TaskEvent[];
}

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'outline' | 'solid' | 'ghost';
  size?: 'md' | 'sm';
  block?: boolean;
  /** true for a right arrow, or a glyph. */
  arrow?: boolean | string;
}
export interface FieldProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  hint?: string;
  error?: string;
}
export interface TagProps { status?: TaskStatus | 'fake' | 'neutral'; children?: React.ReactNode }
export interface BannerProps { tone?: 'info' | 'fake'; label?: string; children: React.ReactNode }
export interface MarksProps {
  sent?: string | boolean;
  received?: string | boolean;
  role: Role;
  onSent?: () => void;
  onReceived?: () => void;
}
export interface TotalsProps { owed: number; sent: number; confirmed: number; currency?: string }
export interface EventLineProps { type: 'moved' | 'removed' | 'deleted'; from?: string; to?: string; at?: string; children?: React.ReactNode }
export type View = 'gantt' | 'list' | 'table' | 'kanban';
export interface ViewSwitchProps { value: View; onChange: (view: View) => void; views?: View[] }

export interface TaskViewProps {
  tasks: Task[];
  role?: Role;
  /** Witness name of the reader; limits "Mark received" to their own claims. */
  me?: string;
  /** True only when there are two or more witnesses. */
  canClaim?: boolean;
  onMarkSent?: (task: Task) => void;
  onMarkReceived?: (task: Task) => void;
  onClaim?: (task: Task) => void;
  amount?: number;
  currency?: string;
}
export interface GanttProps extends TaskViewProps { today?: string; from?: string; to?: string }
export interface TaskListProps extends TaskViewProps {}
export interface TaskTableProps extends TaskViewProps {}
export interface KanbanProps extends TaskViewProps {}
export interface TaskViewsProps extends GanttProps {
  title?: string;
  defaultView?: View;
  view?: View;
  onViewChange?: (view: View) => void;
  views?: View[];
}

export interface AuthCardProps { mode?: 'login' | 'invite'; inviter?: string; error?: string; onSubmit?: (values: Record<string, string>) => void }
export interface Witness { name: string; role: 'witness' | 'admin'; state: 'active' | 'invited' }
export interface AccountPanelProps { worker: string; witnesses: Witness[]; me?: string; inviteLink?: string; onInvite?: () => void; onSignOut?: () => void }
export interface AmountProposalProps {
  current: number;
  proposed?: number | null;
  votes?: { name: string; vote: 'agreed' | 'declined' | 'pending' }[];
  role: Role;
  currency?: string;
  onPropose?: (amount: number) => void;
  onAgree?: () => void;
  onDecline?: () => void;
}
export interface InstallStepsProps { installed?: boolean; enabled?: boolean; steps?: string[]; onEnable?: () => void }

export const Button: React.FC<ButtonProps>;
export const Field: React.FC<FieldProps>;
export const Tag: React.FC<TagProps>;
export const Banner: React.FC<BannerProps>;
export const Marks: React.FC<MarksProps>;
export const Totals: React.FC<TotalsProps>;
export const EventLine: React.FC<EventLineProps>;
export const ViewSwitch: React.FC<ViewSwitchProps>;
export const Gantt: React.FC<GanttProps>;
export const TaskList: React.FC<TaskListProps>;
export const TaskTable: React.FC<TaskTableProps>;
export const Kanban: React.FC<KanbanProps>;
export const TaskViews: React.FC<TaskViewsProps>;
export const AuthCard: React.FC<AuthCardProps>;
export const AccountPanel: React.FC<AccountPanelProps>;
export const AmountProposal: React.FC<AmountProposalProps>;
export const InstallSteps: React.FC<InstallStepsProps>;
