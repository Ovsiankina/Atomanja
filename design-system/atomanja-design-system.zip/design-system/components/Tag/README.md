A status word in a hairline box with a 6px mark.

- **You provide:** `status`: `upcoming`, `late`, `sent`, `received`, `fake` or `neutral`. Children override the default word.
- The word is mandatory; colour repeats it, never replaces it.
- `upcoming` is `ink-muted` with a hollow mark. `late`, `sent`, `received` use `late`, `accent`, `confirmed`.
- `fake` is dashed `ink`: use it on anything fed by the admin witness's fake data.
- Also used for votes in `AmountProposal` (Agreed, Declined, Pending).
- Do not invent statuses. A task has exactly four.
