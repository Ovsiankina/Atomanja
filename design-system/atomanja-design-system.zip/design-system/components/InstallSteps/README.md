The notifications setup: numbered "Add to Home Screen" steps for iPhone, then one button.

- **You provide:** `installed` (the app runs from the Home Screen), `enabled` (permission granted), `onEnable`. Optional `steps` to replace the three default sentences.
- The button stays disabled until `installed` is true, with a line explaining why. Once `enabled`, it reads "Notifications enabled" and stays disabled.
- Steps are numbered `/0.1` to `/0.3` and each is one short sentence.
- Show it once after first sign-in and keep it reachable from settings.
