/* @ds-bundle: {"format":4,"namespace":"Atomanja","components":[{"name":"Button"},{"name":"Field"},{"name":"Tag"},{"name":"Banner"},{"name":"Marks"},{"name":"Totals"},{"name":"EventLine"},{"name":"ViewSwitch"},{"name":"Gantt"},{"name":"TaskList"},{"name":"TaskTable"},{"name":"Kanban"},{"name":"TaskViews"},{"name":"AuthCard"},{"name":"AccountPanel"},{"name":"AmountProposal"},{"name":"InstallSteps"}]} */
(function () {
  var R = window.React, h = R.createElement;
  var MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  var STATUS = { upcoming: 'Upcoming', late: 'Late', sent: 'Sent', received: 'Received' };

  function cx() { return Array.prototype.filter.call(arguments, Boolean).join(' '); }
  function omit(p, keys) { var o = {}; for (var k in p) if (keys.indexOf(k) < 0) o[k] = p[k]; return o; }
  function day(s) { var p = String(s).slice(0, 10).split('-'); return Math.round(Date.UTC(+p[0], p[1] - 1, +p[2]) / 864e5); }
  function fromDay(n) { return new Date(n * 864e5); }
  function fmt(s) { if (!s || s === true) return ''; var d = fromDay(day(s)); return d.getUTCDate() + ' ' + MONTHS[d.getUTCMonth()]; }
  function label(t, role) { return role === 'witness' ? 'Task ' + t.n : (t.title || 'Task ' + t.n); }
  function money(t, p) { return (t.amount || p.amount || 10) + ' ' + (p.currency || 'CHF'); }
  function key(t) { return t.id || t.n; }

  /* ---------- primitives ---------- */

  function Button(p) {
    var v = p.variant || 'outline';
    return h('button', Object.assign({ type: 'button' }, omit(p, ['variant', 'size', 'block', 'arrow', 'children', 'className']), {
      className: cx('at-btn', 'at-btn--' + v, p.size === 'sm' && 'at-btn--sm', p.block && 'at-btn--block', p.className)
    }), h('span', null, p.children), p.arrow ? h('span', { className: 'at-btn__arrow', 'aria-hidden': true }, p.arrow === true ? '→' : p.arrow) : null);
  }

  function Field(p) {
    var id = p.id || 'at-f-' + String(p.name || p.label || '').replace(/\W+/g, '-').toLowerCase();
    return h('div', { className: cx('at-field', p.error && 'at-field--error', p.className) },
      h('label', { className: 'at-label', htmlFor: id }, p.label),
      h('input', Object.assign({ id: id, className: 'at-input' }, omit(p, ['label', 'hint', 'error', 'className', 'id']))),
      p.error || p.hint ? h('p', { className: 'at-field__hint' }, p.error || p.hint) : null);
  }

  function Tag(p) {
    var s = p.status || 'neutral';
    return h('span', { className: cx('at-tag', 'at-tag--' + s) }, h('i', { className: 'at-tag__mark', 'aria-hidden': true }), p.children || STATUS[s]);
  }

  function Banner(p) {
    return h('div', { className: cx('at-banner', 'at-banner--' + (p.tone || 'info')), role: 'status' },
      p.label ? h('span', { className: 'at-banner__label' }, p.label) : null, h('span', null, p.children));
  }

  function check(name, on) {
    return h('span', { className: cx('at-check', on && 'is-on') }, h('i', { className: 'at-check__box', 'aria-hidden': true }, on ? '✓' : ''), name, h('span', { className: 'at-sr' }, on ? ': yes' : ': not yet'));
  }

  function mark(name, on, action, actionLabel) {
    return h('div', { className: cx('at-mark', on && 'at-mark--on') },
      h('span', { className: 'at-mark__box', 'aria-hidden': true }, on ? '✓' : ''),
      h('span', { className: 'at-label' }, name),
      on ? h('span', { className: 'at-mark__at' }, fmt(on) || 'Yes')
        : action ? h(Button, { size: 'sm', variant: 'solid', onClick: action, className: 'at-mark__act' }, actionLabel)
          : h('span', { className: 'at-mark__at' }, 'Not yet'));
  }

  function Marks(p) {
    return h('div', { className: 'at-marks' },
      mark('Sent', p.sent, p.role === 'worker' ? p.onSent : null, 'Mark sent'),
      mark('Received', p.received, p.role === 'witness' ? p.onReceived : null, 'Mark received'));
  }

  function Totals(p) {
    var items = [['Owed', p.owed, 'late'], ['Sent', p.sent, 'sent'], ['Confirmed', p.confirmed, 'received']];
    return h('dl', { className: 'at-totals' }, items.map(function (it, i) {
      return h('div', { className: cx('at-total', it[1] > 0 && 'at-total--' + it[2]), key: it[0] },
        h('dt', { className: 'at-label' }, h('span', { className: 'at-index' }, '/0.' + (i + 1)), ' ', it[0]),
        h('dd', { className: 'at-total__n' }, it[1], h('span', { className: 'at-unit' }, p.currency || 'CHF')));
    }));
  }

  var GLYPH = { moved: '↦', removed: '∅', deleted: '×' };
  function eventText(e) {
    if (e.type === 'moved') return 'Deadline moved to ' + fmt(e.to) + ' in Vikunja. ' + fmt(e.from) + ' still counts.';
    if (e.type === 'removed') return 'Deadline removed in Vikunja. It still counts.';
    return 'Task deleted in Vikunja. The deadline still counts.';
  }
  function EventLine(p) {
    return h('p', { className: 'at-event' },
      h('span', { className: 'at-event__g', 'aria-hidden': true }, GLYPH[p.type] || '·'),
      h('span', null, p.children || eventText(p)),
      p.at ? h('time', { className: 'at-event__at' }, fmt(p.at)) : null);
  }
  function events(t) { return (t.events || []).map(function (e, i) { return h(EventLine, Object.assign({ key: i }, e)); }); }

  var VIEWS = [['gantt', 'Gantt'], ['list', 'List'], ['table', 'Table'], ['kanban', 'Kanban']];
  function ViewSwitch(p) {
    return h('div', { className: 'at-switch', role: 'tablist', 'aria-label': 'View' },
      VIEWS.filter(function (v) { return !p.views || p.views.indexOf(v[0]) >= 0; }).map(function (v) {
        var on = p.value === v[0];
        return h('button', { key: v[0], type: 'button', role: 'tab', 'aria-selected': on, className: cx('at-switch__b', on && 'is-on'), onClick: function () { p.onChange && p.onChange(v[0]); } }, v[1]);
      }));
  }

  /* ---------- task views (one data shape, four layouts) ---------- */

  function action(t, p) {
    if (t.status === 'upcoming') return null;
    var b = function (text, fn) { return h(Button, { size: 'sm', variant: 'solid', onClick: function () { fn(t); } }, text); };
    if (p.role === 'witness') {
      if (!t.claimedBy) return p.canClaim && p.onClaim ? b('Claim', p.onClaim) : null;
      if (!t.received && p.onMarkReceived && (!p.me || p.me === t.claimedBy)) return b('Mark received', p.onMarkReceived);
      return null;
    }
    return !t.sent && p.onMarkSent ? b('Mark sent', p.onMarkSent) : null;
  }
  function claimed(t) { return t.claimedBy ? 'Claimed by ' + t.claimedBy : 'Unclaimed'; }
  function checks(t) { return h('span', { className: 'at-checks' }, check('Sent', t.sent), check('Received', t.received)); }

  function Gantt(p) {
    var role = p.role || 'worker', ts = p.tasks || [];
    var today = day(p.today || new Date().toISOString());
    var lo = today, hi = today;
    ts.forEach(function (t) {
      var d = day(t.deadline);
      lo = Math.min(lo, d, t.start ? day(t.start) : d);
      hi = Math.max(hi, d, t.movedTo ? day(t.movedTo) : d);
    });
    var from = p.from ? day(p.from) : lo - 1, to = p.to ? day(p.to) : hi + 6, n = to - from + 1;
    var pct = function (x) { return (x / n * 100) + '%'; };
    var days = [];
    for (var i = 0; i < n; i++) {
      var dt = fromDay(from + i);
      days.push(h('div', { key: i, className: cx('at-gantt__day', dt.getUTCDay() === 1 && 'is-mon', from + i === today && 'is-today') },
        i === 0 || dt.getUTCDate() === 1 ? h('span', { className: 'at-gantt__month' }, MONTHS[dt.getUTCMonth()]) : null,
        h('span', null, dt.getUTCDate())));
    }
    var rows = ts.map(function (t) {
      var d = day(t.deadline) - from, s = (t.start ? day(t.start) : day(t.deadline)) - from, now = today - from + 0.5;
      var m = t.movedTo ? day(t.movedTo) - from + 0.5 : 0;
      var over = t.status === 'late' && now > d + 1;
      var note = t.status === 'upcoming' ? fmt(t.deadline) : STATUS[t.status] + ' · ' + money(t, p);
      return h('div', { key: key(t), className: cx('at-gantt__row', 'at-gantt__row--' + t.status) },
        h('div', { className: 'at-gantt__label' }, h('i', { className: 'at-gantt__dot', 'aria-hidden': true }), h('span', { className: 'at-gantt__title' }, label(t, role))),
        h('div', { className: 'at-gantt__track' },
          h('i', { className: 'at-gantt__today' , style: { left: pct(now) } }),
          h('i', { className: 'at-gantt__bar', style: { left: pct(s), width: pct(d - s + 1) } }),
          over ? h('i', { className: 'at-gantt__over', style: { left: pct(d + 1), width: pct(now - d - 1) } }) : null,
          h('i', { className: 'at-gantt__lock', style: { left: pct(d + 1) }, title: 'Locked deadline ' + fmt(t.deadline) }),
          m ? h('i', { className: 'at-gantt__moved', style: { left: pct(m) }, title: 'Moved to ' + fmt(t.movedTo) + ' in Vikunja' }) : null,
          h('span', { className: 'at-gantt__note', style: { left: pct(Math.max(d + 1, over ? now : 0, m ? m + 0.5 : 0)) } }, note)));
    });
    return h('div', { className: 'at-gantt', role: 'group', 'aria-label': 'Timeline' },
      h('div', { className: 'at-gantt__grid', style: { '--days': n, minWidth: 'calc(var(--gantt-label) + ' + n + ' * var(--day))' } },
        h('div', { className: 'at-gantt__row at-gantt__row--head' },
          h('div', { className: 'at-gantt__label' }, h('span', { className: 'at-label' }, role === 'witness' ? 'Task no.' : 'Task')),
          h('div', { className: 'at-gantt__track at-gantt__days' }, days)),
        rows));
  }

  function TaskList(p) {
    var role = p.role || 'worker';
    return h('ul', { className: 'at-list' }, (p.tasks || []).map(function (t) {
      var debt = t.status !== 'upcoming';
      return h('li', { key: key(t), className: cx('at-row', 'at-row--' + t.status) },
        h('div', { className: 'at-row__when' }, h('span', { className: 'at-mono' }, fmt(t.deadline)), role === 'worker' ? h('span', { className: 'at-index' }, '#' + t.n) : null),
        h('div', { className: 'at-row__main' },
          h('div', { className: 'at-row__head' }, h('span', { className: 'at-row__title' }, label(t, role)), h(Tag, { status: t.status })),
          debt ? h('div', { className: 'at-row__debt' }, h('span', { className: 'at-mono' }, money(t, p)), h('span', { className: 'at-muted' }, claimed(t)), checks(t)) : null,
          events(t)),
        h('div', { className: 'at-row__act' }, action(t, p)));
    }));
  }

  function TaskTable(p) {
    var role = p.role || 'worker';
    var th = function (s) { return h('th', { key: s, scope: 'col' }, s); };
    return h('div', { className: 'at-tablewrap' }, h('table', { className: 'at-table' },
      h('thead', null, h('tr', null, ['No.', role === 'witness' ? null : 'Task', 'Deadline', 'Status', 'Amount', 'Claimed by', 'Marks', ''].filter(function (x) { return x !== null; }).map(th))),
      h('tbody', null, (p.tasks || []).map(function (t) {
        var debt = t.status !== 'upcoming';
        return h('tr', { key: key(t), className: 'at-table__row--' + t.status },
          h('td', { className: 'at-mono' }, t.n),
          role === 'witness' ? null : h('td', { className: 'at-table__title' }, label(t, role), events(t)),
          h('td', { className: 'at-mono' }, fmt(t.deadline)),
          h('td', null, h(Tag, { status: t.status })),
          h('td', { className: 'at-mono' }, debt ? money(t, p) : ''),
          h('td', null, debt ? (t.claimedBy || 'Unclaimed') : ''),
          h('td', null, debt ? checks(t) : null),
          h('td', { className: 'at-table__act' }, action(t, p)));
      }))));
  }

  var COLS = [['upcoming', 'Upcoming'], ['late', 'Late'], ['sent', 'Sent'], ['received', 'Confirmed']];
  function Kanban(p) {
    var role = p.role || 'worker';
    return h('div', { className: 'at-kanban' }, COLS.map(function (c, i) {
      var ts = (p.tasks || []).filter(function (t) { return t.status === c[0]; });
      return h('section', { key: c[0], className: cx('at-col', 'at-col--' + c[0]) },
        h('header', { className: 'at-col__head' }, h('span', { className: 'at-label' }, h('span', { className: 'at-index' }, '/0.' + (i + 1)), ' ', c[1]), h('span', { className: 'at-mono' }, ts.length)),
        ts.length ? ts.map(function (t) {
          var debt = t.status !== 'upcoming';
          return h('article', { key: key(t), className: 'at-card' },
            h('div', { className: 'at-card__top' }, h('span', { className: 'at-mono' }, fmt(t.deadline)), debt ? h('span', { className: 'at-mono' }, money(t, p)) : null),
            h('div', { className: 'at-card__title' }, label(t, role)),
            debt ? h('div', { className: 'at-card__meta' }, h('span', { className: 'at-muted' }, claimed(t)), checks(t)) : null,
            events(t), action(t, p));
        }) : h('p', { className: 'at-muted' }, 'None'));
    }));
  }

  function TaskViews(p) {
    var st = R.useState(p.defaultView || 'gantt'), v = p.view || st[0];
    var V = { gantt: Gantt, list: TaskList, table: TaskTable, kanban: Kanban }[v] || Gantt;
    return h('div', { className: 'at-views' },
      h('div', { className: 'at-views__bar' },
        h('span', { className: 'at-label' }, p.title || 'Tasks', ' ', h('span', { className: 'at-index' }, (p.tasks || []).length)),
        h(ViewSwitch, { value: v, views: p.views, onChange: function (x) { st[1](x); p.onViewChange && p.onViewChange(x); } })),
      h(V, omit(p, ['view', 'defaultView', 'onViewChange', 'title', 'views'])));
  }

  /* ---------- accounts ---------- */

  function AuthCard(p) {
    var invite = p.mode === 'invite';
    return h('form', {
      className: cx('at-auth', invite && 'at-auth--invite'),
      onSubmit: function (e) { e.preventDefault(); if (p.onSubmit) { var o = {}; new FormData(e.target).forEach(function (v, k) { o[k] = v; }); p.onSubmit(o); } }
    },
      h('p', { className: 'at-label' }, invite ? 'Invitation' : 'Sign in'),
      h('h1', { className: 'at-auth__title' }, invite ? (p.inviter || 'A worker') + ' asks you to witness their deadlines.' : 'Atomanja'),
      invite ? h('p', { className: 'at-muted' }, 'Set a password to accept. You will see task numbers and deadlines, never titles.') : null,
      invite ? null : h(Field, { label: 'Name', name: 'name', autoComplete: 'username', required: true }),
      h(Field, { label: invite ? 'New password' : 'Password', name: 'password', type: 'password', autoComplete: invite ? 'new-password' : 'current-password', required: true }),
      invite ? h(Field, { label: 'Repeat password', name: 'repeat', type: 'password', autoComplete: 'new-password', required: true }) : null,
      p.error ? h('p', { className: 'at-auth__error', role: 'alert' }, p.error) : null,
      h(Button, { type: 'submit', variant: 'solid', block: true, arrow: true }, invite ? 'Accept invite' : 'Sign in'));
  }

  function AccountPanel(p) {
    var ws = p.witnesses || [];
    var person = function (name, role, state, k) {
      return h('li', { key: k, className: 'at-person' },
        h('span', { className: 'at-person__name' }, name, p.me && p.me === name ? h('span', { className: 'at-index' }, ' You') : null),
        h('span', { className: 'at-label' }, role), h('span', { className: 'at-muted' }, state));
    };
    return h('section', { className: 'at-account' },
      h('header', { className: 'at-account__head' }, h('span', { className: 'at-label' }, 'Accounts'), h('span', { className: 'at-mono' }, ws.length + 1)),
      h('ul', { className: 'at-people' },
        person(p.worker, 'Worker', 'Owes when late', 'w'),
        ws.map(function (w, i) {
          return person(w.name || 'Open invite', w.role === 'admin' ? 'Admin witness' : 'Witness',
            w.role === 'admin' ? 'Sees fake data only' : w.state === 'invited' ? 'Invite not accepted yet' : 'Active', i);
        })),
      p.onInvite ? h('div', { className: 'at-account__invite' },
        p.inviteLink ? h(Field, { label: 'Invite link', readOnly: true, value: p.inviteLink, onFocus: function (e) { e.target.select(); }, hint: 'Send it yourself. The witness sets their own password.' }) : null,
        h(Button, { onClick: p.onInvite, arrow: true }, p.inviteLink ? 'Create another link' : 'Invite a witness')) : null,
      p.onSignOut ? h(Button, { variant: 'ghost', onClick: p.onSignOut }, 'Sign out') : null);
  }

  function AmountProposal(p) {
    var c = p.currency || 'CHF', votes = p.votes || [], st = R.useState('');
    var unit = h('span', { className: 'at-unit' }, c);
    if (p.proposed == null) {
      return h('section', { className: 'at-proposal' },
        h('p', { className: 'at-label' }, 'Amount per late task'),
        h('p', { className: 'at-proposal__n' }, p.current, unit),
        p.role === 'worker' && p.onPropose ? h('form', { className: 'at-proposal__form', onSubmit: function (e) { e.preventDefault(); if (st[0]) p.onPropose(Number(st[0])); } },
          h(Field, { label: 'Propose a new amount', name: 'amount', type: 'number', min: 1, inputMode: 'numeric', value: st[0], onChange: function (e) { st[1](e.target.value); }, hint: 'It changes only when every witness agrees.' }),
          h(Button, { type: 'submit', arrow: true }, 'Propose')) : null);
    }
    var agreed = votes.filter(function (v) { return v.vote === 'agreed'; }).length;
    return h('section', { className: 'at-proposal' },
      h('p', { className: 'at-label' }, 'Proposed amount change'),
      h('p', { className: 'at-proposal__n' }, p.current, h('span', { className: 'at-proposal__to', 'aria-label': 'to' }, '→'), p.proposed, unit),
      h('p', { className: 'at-muted' }, agreed + ' of ' + votes.length + ' witnesses agreed. It changes only when all agree.'),
      h('ul', { className: 'at-people' }, votes.map(function (v) {
        return h('li', { key: v.name, className: 'at-person' }, h('span', { className: 'at-person__name' }, v.name),
          h(Tag, { status: v.vote === 'agreed' ? 'received' : v.vote === 'declined' ? 'late' : 'upcoming' }, v.vote === 'agreed' ? 'Agreed' : v.vote === 'declined' ? 'Declined' : 'Pending'));
      })),
      p.role === 'witness' && p.onAgree ? h('div', { className: 'at-proposal__act' },
        h(Button, { variant: 'solid', onClick: p.onAgree }, 'Agree'), h(Button, { onClick: p.onDecline }, 'Decline')) : null);
  }

  function InstallSteps(p) {
    var steps = p.steps || ['Open Atomanja in Safari.', 'Tap Share, then "Add to Home Screen".', 'Open Atomanja from the Home Screen.'];
    return h('section', { className: 'at-install' },
      h('p', { className: 'at-label' }, 'Notifications on iPhone'),
      h('ol', { className: 'at-steps' }, steps.map(function (s, i) {
        return h('li', { key: i, className: 'at-step' }, h('span', { className: 'at-index' }, '/0.' + (i + 1)), h('span', null, s));
      })),
      h(Button, { variant: 'solid', block: true, disabled: !p.installed || !!p.enabled, onClick: p.onEnable }, p.enabled ? 'Notifications enabled' : 'Enable notifications'),
      !p.installed ? h('p', { className: 'at-muted' }, 'The button unlocks once Atomanja runs from the Home Screen.') : null);
  }

  window.Atomanja = {
    Button: Button, Field: Field, Tag: Tag, Banner: Banner, Marks: Marks, Totals: Totals, EventLine: EventLine, ViewSwitch: ViewSwitch,
    Gantt: Gantt, TaskList: TaskList, TaskTable: TaskTable, Kanban: Kanban, TaskViews: TaskViews,
    AuthCard: AuthCard, AccountPanel: AccountPanel, AmountProposal: AmountProposal, InstallSteps: InstallSteps
  };
})();
