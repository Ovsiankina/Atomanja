The Gantt as four fixed columns: Upcoming, Late, Sent, Confirmed.

- **You provide:** the same `tasks`, `role` and handlers as every task view.
- Columns are the four task states in order; they are not configurable and cards cannot be dragged. A card moves only when a mark is set or a deadline passes.
- Each column head shows its `/0.n` index and count. Cards in Late take a `late` border.
- The card's button is the only way forward: "Mark sent" for the worker, "Claim" or "Mark received" for a witness.
- On a phone the board scrolls sideways, one column at a time.
