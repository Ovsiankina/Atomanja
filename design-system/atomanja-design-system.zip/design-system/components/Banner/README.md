A full-width strip that says something about the whole screen.

- **You provide:** `tone` (`info` default, `fake`), a short `label`, and one sentence as children.
- `tone="fake"` is required at the top of the admin view and stays visible while scrolling. Its dashed `ink` border is the system's sign for "not real".
- Use `info` for standing facts ("Atomanja only counts. Payment happens outside it.").
- Not for errors on a field (use `Field` `error`) and not for transient confirmations.
