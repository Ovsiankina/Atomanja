The Gantt as a dense table, one column per fact.

- **You provide:** the same `tasks`, `role` and handlers as every task view.
- Columns: No., Task, Deadline, Status, Amount, Claimed by, Marks, action. `role="witness"` drops the Task column.
- Use it on desktop when comparing many debts. On a phone it scrolls sideways; prefer `TaskList` there.
- Numbers, dates and amounts are in `data`. Events sit under the title in the Task cell.
