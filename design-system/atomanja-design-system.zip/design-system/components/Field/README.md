A labelled text input on `surface-sunken` with a `line-strong` border.

- **You provide:** `label`, and any input attribute (`name`, `type`, `value`, `onChange`, `autoComplete`, `readOnly`). Optional `hint` and `error`.
- The label is always visible in `label` style; never use a placeholder as the label.
- `error` replaces the hint and turns the border and message `late`. Say what is wrong in one sentence.
- Use `readOnly` for the invite link; the field selects itself on focus in `AccountPanel`.
